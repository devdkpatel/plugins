<?php
/**
 * Plugin Name: Theme Exporter
 * Description: Export theme, plugins, and content. Allows demo import on new installs.
 * Version: 1.0
 * Author: Sample
 */

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'includes/export-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/import-functions.php';

// Add Export option to admin menu
add_action('admin_menu', function () {
    add_submenu_page(
        'tools.php',
        'Export Theme Package',
        'Export Theme Package',
        'manage_options',
        'theme-exporter',
        'dte_export_site_data'
    );
});
