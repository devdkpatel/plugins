<?php
// Add export menu
add_action('admin_menu', function () {
    add_menu_page(
        'Theme Exporter',
        'Theme Exporter',
        'manage_options',
        'dte-export',
        'dte_export_page_callback',
        'dashicons-download',
        100
    );
});

function dte_export_page_callback() {
    echo '<div class="wrap"><h1>Export Demo Package</h1>';

    if (isset($_GET['run_export'])) {
        dte_export_site_data();
    } else {
        echo '<p>Click the button below to export the current theme, plugins, and content as a demo package.</p>';
        echo '<a href="' . esc_url(admin_url('admin.php?page=dte-export&run_export=1')) . '" class="button button-primary">Export Now</a>';
    }

    echo '</div>';
}
