<?php

function dte_export_site_data() {
    if (!current_user_can('manage_options')) return;

    $upload_dir = wp_upload_dir();
    $temp_export_dir = $upload_dir['basedir'] . '/demo-export/';
    if (!file_exists($temp_export_dir)) mkdir($temp_export_dir, 0755, true);

    // Export content
    $xml_file = $temp_export_dir . 'demo-content.xml';
    require_once ABSPATH . 'wp-admin/includes/export.php';
    ob_start();
    export_wp(['content' => 'all']);
    file_put_contents($xml_file, ob_get_clean());

    // Export active plugins
    $plugins = get_option('active_plugins');
    $plugins_file = $temp_export_dir . 'plugins.json';
    file_put_contents($plugins_file, json_encode($plugins, JSON_PRETTY_PRINT));

    // Copy files into theme's /import/ folder
    $theme = wp_get_theme();
    $theme_slug = $theme->get_stylesheet();
    $theme_dir = get_theme_root($theme_slug) . '/' . $theme_slug;
    $import_dir = $theme_dir . '/import/';

    if (!file_exists($import_dir)) mkdir($import_dir, 0755, true);
    copy($xml_file, $import_dir . 'demo-content.xml');
    copy($plugins_file, $import_dir . 'plugins.json');

    // Zip the theme folder
    $theme_zip = $upload_dir['basedir'] . '/' . $theme_slug . '-demo.zip';
    $zip = new ZipArchive();
    if ($zip->open($theme_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($theme_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($theme_dir) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
    }

    echo '<div class="notice notice-success"><p>Export complete. <a class="button button-primary" href="' . esc_url($upload_dir['baseurl'] . '/' . $theme_slug . '-demo.zip') . '" download>Download Theme Package</a></p></div>';
}
