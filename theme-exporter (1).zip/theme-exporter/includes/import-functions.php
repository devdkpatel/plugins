<?php



// Show notice after theme activation

add_action('admin_notices', function () {

    if (get_option('dte_show_import_notice') && current_user_can('manage_options')) {

        $import_url = esc_url(admin_url('admin.php?action=dte_import_demo'));

        echo '<div class="notice notice-info is-dismissible">

            <p><strong>This theme supports demo import.</strong></p>

            <p><a href="' . $import_url . '" class="button button-primary">Import Demo Data</a></p>

        </div>';

        delete_option('dte_show_import_notice');

    }

});



// Set flag on theme switch

add_action('after_switch_theme', function () {

    update_option('dte_show_import_notice', true);

});



// Handle import logic

add_action('admin_action_dte_import_demo', function () {

    $theme = wp_get_theme();

    $theme_slug = $theme->get_stylesheet();

    $theme_dir = get_theme_root($theme_slug) . '/' . $theme_slug;

    $import_dir = $theme_dir . '/import/';



    if (!file_exists($import_dir . 'plugins.json') || !file_exists($import_dir . 'demo-content.xml')) {

        wp_die('Demo files not found in theme import folder.');

    }



    // Activate plugins

    $plugins = json_decode(file_get_contents($import_dir . 'plugins.json'), true);

    require_once ABSPATH . 'wp-admin/includes/plugin.php';

    foreach ($plugins as $plugin) {

        if (!is_plugin_active($plugin)) {

            activate_plugin($plugin);

        }

    }



    // Import content

    if (!class_exists('WP_Import')) {

        if (file_exists(WP_PLUGIN_DIR . '/wordpress-importer/wordpress-importer.php')) {

            require_once WP_PLUGIN_DIR . '/wordpress-importer/wordpress-importer.php';

        } else {

            wp_die('WordPress Importer plugin is required.');

        }

    }



    $importer = new WP_Import();

    $importer->fetch_attachments = true;

    $importer->import($import_dir . 'demo-content.xml');



    wp_redirect(admin_url('themes.php?imported=1'));

    exit;

});



// Add button inside Appearance > Themes active theme panel

add_action('admin_footer', function () {

    if (get_current_screen()->id !== 'themes') return;



    $import_url = esc_url(admin_url('admin.php?action=dte_import_demo'));

    ?>

    <script>

    jQuery(document).ready(function($) {

        const activeTheme = $(".theme.active .theme-actions");

        if (activeTheme.length) {

            activeTheme.append('<a href="<?php echo $import_url; ?>" class="button button-primary">Import Demo</a>');

        }

    });

    </script>

    <?php

});

